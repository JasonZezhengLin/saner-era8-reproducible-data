import base64, collections, datetime, hashlib, json, statistics, sys, os
from pathlib import Path

def dt(x):
    return datetime.datetime.fromisoformat(x.replace('Z', '+00:00'))
TERMINAL = {'ActivitiesBugNotApplicable', 'ActivitiesBugSpam', 'ActivitiesBugInformative', 'ActivitiesBugResolved', 'ActivitiesBugDuplicate'}
DISCLOSURE = {'ActivitiesManuallyDisclosed', 'ActivitiesReportBecamePublic'}

def summarize_timelines(records, cohort):
    ids = [row['rid'] for row in records]
    rows = []
    event_ledger = []
    for r in records:
        ns = sorted(r['nodes'], key=lambda x: (dt(x['created_at']), x['id']))
        assert len({n['id'] for n in ns}) == len(ns)
        assert not any((n.get('internal') is True for n in ns))
        filed = [n for n in ns if n['__typename'] == 'ActivitiesBugFiled']
        terminal = [n for n in ns if n['__typename'] in TERMINAL]
        disclosed = [n for n in ns if n['__typename'] in DISCLOSURE]
        comments = [n for n in ns if n['__typename'] == 'ActivitiesComment']
        start = dt(filed[0]['created_at']) if len(filed) == 1 else None
        row = {k: v for k, v in r.items() if k != 'nodes'}
        row.update(activities=len(ns), comments=len(comments), filed_events=len(filed), filed_utc=start.isoformat() if start else None, calendar_year=start.year if start else None, terminal_events=[{'id': n['id'], 'type': n['__typename'], 'utc': n['created_at']} for n in terminal], disclosure_events=[{'id': n['id'], 'type': n['__typename'], 'utc': n['created_at']} for n in disclosed], reopened_events=[n['id'] for n in ns if n['__typename'] == 'ActivitiesBugReopened'], comment_role_counts=dict(collections.Counter(('customer' if n.get('actor_is_customer') is True else 'noncustomer' if n.get('actor_is_customer') is False else 'unknown' for n in comments))), automated_comment_counts=dict(collections.Counter((str(n.get('automated_response')) for n in comments))), type_counts=dict(collections.Counter((n['__typename'] for n in ns))))
        for mode, cc in [('all_visible', comments), ('exclude_explicit_automated', [n for n in comments if n.get('automated_response') is not True])]:
            m = {'comments': len(cc), 'customer_comments': sum((n.get('actor_is_customer') is True for n in cc))}
            for label, when in [('first_terminal', dt(terminal[0]['created_at']) if terminal else None), ('last_terminal', dt(terminal[-1]['created_at']) if terminal else None), ('first_public_disclosure', dt(disclosed[0]['created_at']) if disclosed else None)]:
                for role, z in [('all', cc), ('customer', [n for n in cc if n.get('actor_is_customer') is True]), ('noncustomer', [n for n in cc if n.get('actor_is_customer') is False]), ('unknown', [n for n in cc if n.get('actor_is_customer') is None])]:
                    m[label + '_' + role] = None if when is None else {'before': sum((dt(n['created_at']) < when for n in z)), 'at_same_timestamp': sum((dt(n['created_at']) == when for n in z)), 'after': sum((dt(n['created_at']) > when for n in z)), 'through_cutoff_lower_upper': [sum((dt(n['created_at']) < when for n in z)), sum((dt(n['created_at']) <= when for n in z))]}
            m['filed_horizons'] = {}
            for day in [7, 30, 90]:
                end = start + datetime.timedelta(days=day) if start else None
                complete = bool(end and dt(r['capture_utc']) >= end)
                z = [n for n in cc if start <= dt(n['created_at']) <= end] if complete else []
                m['filed_horizons'][str(day)] = {'followup_complete': complete, 'all_comments': len(z) if complete else None, 'customer_comments': sum((n.get('actor_is_customer') is True for n in z)) if complete else None}
            row[mode] = m
        for n in ns:
            event_ledger.append({'rid': r['rid'], 'group': r['group'], 'source_hashes': r['source_hashes'], **n})
        rows.append(row)

    def aggregate(xs):

        def dist(v):
            return {'n': len(v), 'sum': sum(v), 'min': min(v) if v else None, 'median': statistics.median(v) if v else None, 'max': max(v) if v else None}
        out = {'reports': len(xs), 'activities': sum((x['activities'] for x in xs)), 'comments': dist([x['comments'] for x in xs]), 'customer_comments': dist([x['all_visible']['customer_comments'] for x in xs]), 'reports_reopened': sum((bool(x['reopened_events']) for x in xs)), 'submitted_year_counts': dict(collections.Counter((x['submitted_year'] for x in xs))), 'terminal_event_types': dict(collections.Counter((t['type'] for x in xs for t in x['terminal_events'])))}
        for mode in ['all_visible', 'exclude_explicit_automated']:
            q = {}
            for cutoff in ['first_terminal', 'last_terminal', 'first_public_disclosure']:
                q[cutoff] = {}
                for role in ['all', 'customer', 'noncustomer', 'unknown']:
                    z = [x[mode][cutoff + '_' + role] for x in xs if x[mode][cutoff + '_' + role] is not None]
                    q[cutoff][role] = {'reports_with_cutoff': len(z), 'before': sum((y['before'] for y in z)), 'same_timestamp': sum((y['at_same_timestamp'] for y in z)), 'after': sum((y['after'] for y in z)), 'reports_with_after': sum((y['after'] > 0 for y in z)), 'missing_cutoff_reports': len(xs) - len(z)}
            q['filed_horizons'] = {str(day): {'reports_complete': sum((x[mode]['filed_horizons'][str(day)]['followup_complete'] for x in xs)), 'customer_comments': dist([x[mode]['filed_horizons'][str(day)]['customer_comments'] for x in xs if x[mode]['filed_horizons'][str(day)]['followup_complete']])} for day in [7, 30, 90]}
            out[mode] = q
        return out
    by_id = {r['rid']: r for r in rows}
    annotations = []
    for n in event_ledger:
        if n['__typename'] != 'ActivitiesComment':
            continue
        r = by_id[n['rid']]
        first = r['terminal_events'][0]['utc'] if r['terminal_events'] else None
        last = r['terminal_events'][-1]['utc'] if r['terminal_events'] else None
        if first and dt(n['created_at']) > dt(first):
            annotations.append({**n, 'first_terminal_utc': first, 'last_terminal_utc': last, 'after_last_terminal': dt(n['created_at']) > dt(last), 'reopened': bool(r['reopened_events']), 'submitted_year': r['submitted_year'], 'public_index_substate': r['public_index_substate'], 'coding_fields_required': ['technical_evidence', 'administration_disclosure', 'authorship_dispute', 'mixed', 'uncertain'], 'coding_status': 'uncoded', 'role': 'customer' if n.get('actor_is_customer') is True else 'noncustomer' if n.get('actor_is_customer') is False else 'unknown'})
    strata = {'all': aggregate(rows), 'reopened': aggregate([x for x in rows if x['reopened_events']]), 'not_reopened': aggregate([x for x in rows if not x['reopened_events']]), 'by_submitted_year': {str(y): aggregate([x for x in rows if x['submitted_year'] == y]) for y in sorted({x['submitted_year'] for x in rows})}, 'by_index_substate': {str(y): aggregate([x for x in rows if x['public_index_substate'] == y]) for y in sorted({x['public_index_substate'] for x in rows}, key=str)}, 'by_last_terminal_type': {str(y): aggregate([x for x in rows if (x['terminal_events'][-1]['type'] if x['terminal_events'] else None) == y]) for y in sorted({x['terminal_events'][-1]['type'] if x['terminal_events'] else None for x in rows}, key=str)}}
    out = {'denominator': {'public_index_count': cohort['public_index_count'], 'eligible_common_submission_window': len(ids), 'complete_timelines': len(rows), 'known_discovery_index_coverage': cohort['known_discovery_index_coverage'], 'unknown_private_and_unindexed_reports': True, 'capture_is_atomic': False}, 'records': rows, 'aggregate': strata, 'post_first_terminal_comments_requiring_coding': len(annotations)}
    return out
