from pathlib import Path
import json
from analysis import calc

ROOT = Path(__file__).resolve().parent

def load(name):
    return [json.loads(line) for line in (ROOT / name).read_text(encoding="utf-8").splitlines() if line.strip()]

def public_result(value):
    if isinstance(value, dict):
        return {key: public_result(item) for key, item in value.items() if key != "scope"}
    if isinstance(value, list):
        return [public_result(item) for item in value]
    return value

result = public_result(calc(load("events.jsonl"), load("annotations_a.jsonl"), load("annotations_b.jsonl")))
expected = json.loads((ROOT / "expected_results.json").read_text(encoding="utf-8"))
if result != expected:
    raise SystemExit("Reproduced results differ from expected_results.json")
(ROOT / "results.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"reports": len(result["endpoint_times117"]), "activities": sum(result["event_counts"].values()), "coded_comments": len(result["comments"]), "annotation_agreements": result["agreement_n"], "annotation_disagreements": result["disagreements_n"], "results_match": True}, sort_keys=True))

from timeline_analysis import summarize_timelines

def clean_timeline(value):
    if isinstance(value, dict):
        return {key: clean_timeline(item) for key, item in value.items() if key not in {"source_hashes"}}
    if isinstance(value, list):
        return [clean_timeline(item) for item in value]
    return value

index = json.loads((ROOT / "public_index.json").read_text(encoding="utf-8"))
reports = json.loads((ROOT / "report_timelines.json").read_text(encoding="utf-8"))
selected = {row["rid"] for row in index if "2023-01-01" <= row["submitted_at"][:10] <= "2025-07-15"}
assert len(index) == 638 and selected == {row["rid"] for row in reports}
for row in reports:
    row["source_hashes"] = []
cohort = {"public_index_count": len(index), "known_discovery_index_coverage": {"known_discovery_count": 21, "present_count": 21, "missing_ids": []}}
timeline_result = json.loads(json.dumps(clean_timeline(summarize_timelines(reports, cohort))))
timeline_expected = json.loads((ROOT / "expected_timeline_results.json").read_text(encoding="utf-8"))
if timeline_result != timeline_expected:
    raise SystemExit("Reproduced timeline results differ from expected_timeline_results.json")
(ROOT / "timeline_results.json").write_text(json.dumps(timeline_result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"visible_index": len(index), "eligible_reports": len(selected), "timeline_results_match": True}, sort_keys=True))
