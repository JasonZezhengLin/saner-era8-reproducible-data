def calc(event_rows, annotation_a, annotation_b):
    from collections import defaultdict, Counter
    from datetime import datetime
    import hashlib

    def tm(s):
        return datetime.fromisoformat(s.replace('Z', '+00:00'))
    by = defaultdict(list)
    for e in event_rows:
        by[e['rid']].append(e)
    assert len(by) == 117
    terminal = {'ActivitiesBugInformative', 'ActivitiesBugNotApplicable', 'ActivitiesBugResolved', 'ActivitiesBugSpam'}
    disclosure = {'ActivitiesReportBecamePublic', 'ActivitiesManuallyDisclosed'}
    labs = [{x['event_id']: x for x in seq} for seq in [annotation_a, annotation_b]]
    assert all((len(x) == 76 for x in labs)) and set(labs[0]) == set(labs[1])
    out = []
    sets = {}
    totals = Counter()
    status_total = Counter()
    endpoint_times = []
    for rid, ee in sorted(by.items()):
        tt = sorted(((tm(e['created_at']), e['__typename'], e['id']) for e in ee if e['__typename'] in terminal))
        dd = sorted((tm(e['created_at']) for e in ee if e['__typename'] in disclosure))
        assert tt and dd
        first, last, disc = (tt[0][0], tt[-1][0], dd[0])
        assert first <= last < disc
        reopened = any((e['__typename'] == 'ActivitiesBugReopened' for e in ee))
        status = tt[-1][1]
        endpoint_times.append({'rid': rid, 'first': first.isoformat(), 'last': last.isoformat(), 'disclosure': disc.isoformat(), 'last_status': status, 'reopened': reopened})
        for e in ee:
            if e['__typename'] != 'ActivitiesComment':
                continue
            role = 'customer' if e['actor_is_customer'] is True else 'noncustomer' if e['actor_is_customer'] is False else 'unknown'
            t = tm(e['created_at'])
            eid = e['id']
            ends = {'first': t > first, 'last': t > last, 'disclosure': t > disc}
            if role == 'customer':
                status_total[status] += 1
            for ep, v in ends.items():
                if v:
                    totals[ep, role] += 1
                    if not reopened:
                        totals[ep, role, 'not_reopened'] += 1
                    sets.setdefault(('any', ep, role), set()).add((rid, eid))
            if not ends['first']:
                continue
            assert eid in labs[0]
            h = hashlib.sha256((e['message'] or '').encode()).hexdigest()
            ll = [a[eid] for a in labs]
            for l in ll:
                assert l['rid'] == rid and l['message_sha256'] == h
            assert ll[1]['role'] == role
            row = {'rid': rid, 'event_id': eid, 'message_sha256': h, 'role': role, 'reopened': reopened, 'status': status, 'endpoints': ends, 'between_last_and_disclosure': last < t <= disc, 'technical': ['technical_evidence' in l['domains_present'] for l in ll], 'labels': [l['label'] for l in ll]}
            out.append(row)
            for coder, l in enumerate(ll):
                tech = 'technical_evidence' in l['domains_present']
                for ep, v in ends.items():
                    if v:
                        for stratum, ok in [('all', True), ('customer', role == 'customer'), ('noncustomer', role == 'noncustomer'), ('nonreopened', not reopened), ('customer_nonreopened', role == 'customer' and (not reopened))]:
                            if ok and tech:
                                sets.setdefault((coder, ep, stratum), set()).add((rid, eid))
                if ends['last'] and tech:
                    sets.setdefault((coder, 'last_status', status), set()).add((rid, eid))
                if last < t <= disc and tech:
                    sets.setdefault((coder, 'between', 'all'), set()).add((rid, eid))
    assert len(out) == 76

    def desc(s):
        return {'comments': len(s), 'reports': len({r for r, e in s}), 'units': sorted([list(x) for x in s])}
    summary = {str(k): desc(v) for k, v in sets.items()}
    cross = {}
    for ep in ['first', 'last', 'disclosure', 'between']:
        for stratum in ['all', 'customer', 'noncustomer', 'nonreopened', 'customer_nonreopened']:
            a = sets.get((0, ep, stratum), set())
            b = sets.get((1, ep, stratum), set())
            cross[ep + '/' + stratum] = {'annotation_a': desc(a), 'annotation_b': desc(b), 'intersection': desc(a & b), 'union': desc(a | b)}
    agree = sum((x['labels'][0] == x['labels'][1] for x in out))
    return {'comments': out, 'endpoint_times117': endpoint_times, 'event_counts': dict(Counter((e['__typename'] for e in event_rows))), 'all_comment_counts': {str(k): v for k, v in totals.items()}, 'all_customer_counts_by_last_status': dict(status_total), 'technical_endpoint_comparisons': cross, 'sets': summary, 'agreement_n': agree, 'disagreements_n': 76 - agree, 'scope': 'Independent endpoint/role/time/accounting replay from frozen visible event rows and two unchanged model coding passes. Labels are not human ground truth. Intersection and union are set descriptions, not confidence intervals. No work-time, AI-origin, technical-validity or causal measurement.'}
